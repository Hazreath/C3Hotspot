#!/bin/bash


# URL Blacklist
bl="/home/pi/bl_util/blacklist.bl"
old_bl="/home/pi/bl_util/blacklist_old"
# URL fichier catégories
categories="/home/pi/bl_util/categories"
cat_bl="/home/pi/bl_util/categories.bl"
ip_error="169.51.42.1"

#PARTIE WGET BLACKLISTS =====

#INITIALISATION DE L'ENVIRONNEMENT
cat $bl > $old_bl
echo "" > $bl

while read cat
do
	# Télécharger la blacklist de la catégorie
	wget -P $categories http://dsi.ut-capitole.fr/blacklists/download/$cat.tar.gz
	
	# Vérification du bon déroulement de wget
	wget_ok=$?;
	echo "RETOUR = $wget_ok"
	if [ wget_ok==0 ]; then 
		tar -C $categories -xvf $categories/$cat.tar.gz
		echo "Ajout à la blacklist"
		
		# Ajout de chaque entrée avec ip de redirection
		# vers la page d'erreur
		entries=$(cat $categories/$cat/domains);
		for entry in $entries
		do
			echo "AJOUT à $bl"
			echo "$ip_error $entry"
			echo "$ip_error $entry" >> $bl
		done
		
		
		#cat $cat/domains >> $bl
		
		
	else echo "Le téléchargement de l'archive $cat a échoué !"
	
	fi
done < $cat_bl


# PARTIE BLACKLIST -> IPTABLES

# Nombre de lignes de l'ancienne et de la nouvelle blacklist
: '
old_bl_lines=$(cat $old_bl |wc -l)
bl_lines=$(cat $bl |wc -l)
'
# Si l'ancienne blacklist était plus fournie que la nouvelle
: '
if [ $bl_lines -lt $old_bl_lines ]; then 
	echo "Erreur lors des téléchargements des blacklists."
	echo "La liste précédente restera en vigueur"
	$(cat $old_bl > $bl)
	exit 2 
fi

'
# Nettoyage des archives
echo ""
echo "Les catégories suivantes ont été blacklistées :"
echo "$(ls |grep tar.gz)"
rm -fr $categories/*.tar.gz


